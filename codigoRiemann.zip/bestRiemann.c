/*----------------------------------------------
 * riemann.c - calculo de area bajo la curva
 *----------------------------------------------
 * Sumas de Riemann para calcular la integral f(x)
 *
 * Date:  2021-09-22
 */

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define A 1
#define B 40
#define N 10e6

double f(double x);     //La funcion a integrar
double fpro(double x);
double trapezoides(double a, double b, int n);

int main(int argc, char* argv[]) {
  double integral;
  double a=A, b=B;
  int n=N;
  int thread_count = 4;
  double dx;

  if(argc > 1) {
    a = strtol(argv[1], NULL, 10);
    b = strtol(argv[2], NULL, 10);
    thread_count = strtol(argv[3], NULL, 10);
    n = strtol(argv[4], NULL, 10);
  }

  //---- Aproximacion de la integral
  //h = (b-a)/n;
  int k;
  //---- Ancho de cada trapezoide
  dx = (b-a)/n;
  //---- Valor inicial de la integral (valores extremos)
  integral = (f(a) + f(b)) / 2.0;

  //for paralelizable con pragma omp
  //agregar constructo private(foo) es como declarar dentro del loop manualmente foo
  #pragma omp parallel for reduction(+: integral) num_threads(thread_count)
  for(k = 1; k <= n-1; k++) {
    integral += fpro(a + k*dx);
  }
  integral = integral * dx;

  printf("Con n = %d trapezoides, nuestra aproximacion \n",n);
  printf("de la integral de %f a %f es = %.10f\n", a,b,integral);

  return 0;
}/*main*/

//------------------------------------------
// f
//
// Funcion a ser integrada
// Input: x
//------------------------------------------
double fpro(double x){
  //why not math pow?
  //ver: https://stackoverflow.com/questions/2940367/what-is-more-efficient-using-pow-to-square-or-just-multiply-it-with-itself/2940800
  return x*x;
}
//funcion ineficiente por la
//variable temporal creada
double f(double x) {
  double return_val;

  return_val = x*x;

  return return_val;
}/*f*/
